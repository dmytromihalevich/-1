#створи гру "Лабіринт"!
from pygame import *

window = display.set_mode((700,500))
display.set_caption("LabirnHt")


background_image = image.load("background.jpg")
background = transform.scale(background_image,(700,500))

class  Sprite(sprite.Sprite):
    def __init__(self,p_image,p_x,p_y,p_speed):
        super().__init__()
        self.image = transform.scale(image.load(p_image),(65,65))
        self.speed = p_speed

        self.rect = self.image.get_rect()
        self.rect.x = p_x
        self.rect.y = p_y

    def reset(self):
        window.blit(self.image,(self.rect.x,self.rect.y))


class Player(Sprite):
    def move (self):
        keys = key.get_pressed()
        if keys [K_LEFT] and self.rect.x > 5 :
            self.rect.x -= self.speed
        elif keys [K_RIGHT] and self.rect.x < 640:
            self.rect.x += self.speed
        elif keys [K_UP] and self.rect.y > 5 :
            self.rect.y -= self.speed
        elif keys [K_DOWN] and self.rect.y < 440 :
            self.rect.y += self.speed
            

class Enemy(Sprite):
    direction = "left"
        
    def move(self):
        if self.rect.x <= 70:
            self.direction = "right"
        if self.rect.x >= 620:
            self.direction = "left"

        if self.direction == "left":
            self.rect.x -= self.speed
        else:
            self.rect.x += self.speed 


   
game = True
FPS = 60
clock = time.Clock()

class Wall(sprite.Sprite):
    def __init__(self,rgb,x,y,w,h):
        super().__init__()
        self.rgb = rgb
        self.width = w
        self.height = h
        self.wall = Surface((w,h))
        self.wall.fill(rgb)

        self.rect= self.wall.get_rect()
        self.rect.x= x
        self.rect.y = y 

    def draw(self):
        window.blit(self.wall, (self.rect.x , self.rect.y))

player = Player("hero.png",5, 80 , 4)
monster = Enemy("cyborg.png",  600 , 280, 5)
final = Sprite("treasure.png", 600 , 430, 0 )

w1 = Wall((2,4,55),150,0,200,250)
w2 = Wall((2,4,55),450,100,150,400)
w3 = Wall((2,4,55),150,400,200,300)

mixer.init()
mixer.music.load("jungles.ogg")
mixer.music.play()

font.init()
font = font.Font(None,70)
win = font.render("you win",True, (178,34,34))



while game:
    for e in event.get():
        if e.type == QUIT:
            game = False
 
    window.blit(background,(0, 0))
    player.reset()
    player.move()
    monster.move()
    
    if sprite.collide_rect(player,monster) or sprite.collide_rect(player,w1) or sprite.collide_rect(player,w2):
        player.rect.x = 20
        player.rect.y = 60

    if sprite.collide_rect(player, final):
        window.blit(win,(250,400))
   

    monster.reset()
    w1.draw()
    w2.draw()
    w3.draw()
    final.reset()
    

    display.update()
    clock.tick(60)









display.update()
clock.tick(60)